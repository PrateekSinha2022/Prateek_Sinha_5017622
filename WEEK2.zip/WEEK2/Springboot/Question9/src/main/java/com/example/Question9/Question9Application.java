package com.example.Question9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question9Application {

	public static void main(String[] args) {
		SpringApplication.run(Question9Application.class, args);
	}

}
