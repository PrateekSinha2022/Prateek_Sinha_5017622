package com.question1.question3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
