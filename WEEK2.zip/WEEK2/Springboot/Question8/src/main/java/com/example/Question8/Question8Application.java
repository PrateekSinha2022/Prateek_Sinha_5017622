package com.example.Question8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question8Application {

	public static void main(String[] args) {
		SpringApplication.run(Question8Application.class, args);
	}

}
