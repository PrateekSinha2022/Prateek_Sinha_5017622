package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.library.service.BookService;

public class LibraryManagementApplication {

    public static void main(String[] args) {
        // Load the application context
        ApplicationContext context = new AnnotationConfigApplicationContext(com.library.AppConfig.class);

        // Get the BookService bean
        BookService bookService = context.getBean(BookService.class);

        // Call methods on the BookService to see aspect logging
        bookService.addBook("Effective Java");
        bookService.removeBook("Design Patterns");
    }
}
