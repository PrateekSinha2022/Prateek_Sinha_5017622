package com.library.repository;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository
public class BookRepository {
}
