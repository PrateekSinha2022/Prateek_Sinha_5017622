package com.example.Book_Question2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookQuestion2Application {

	public static void main(String[] args) {
		SpringApplication.run(BookQuestion2Application.class, args);
	}

}
