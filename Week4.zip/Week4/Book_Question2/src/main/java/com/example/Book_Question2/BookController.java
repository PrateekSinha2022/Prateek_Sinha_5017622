package com.example.Book_Question2;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        // Replace with actual logic to fetch books from a repository
        List<Book> books = null; // ...
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {

        Book savedBook = new Book(); // ...
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody
            Book book) {
        // Replace with actual logic to update book in a repository
        Book updatedBook = new Book(); // ...
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable
            Long id) {
        // Replace with actual logic to delete book from a repository
        // ...
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
