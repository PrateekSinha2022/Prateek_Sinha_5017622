package com.example.Book_Question2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookQuestion2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
