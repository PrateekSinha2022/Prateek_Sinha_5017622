package com.example.Week4_Question4;

import jdk.internal.icu.impl.Punycode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.security.auth.callback.PasswordCallback;
import java.net.URI;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerRespository customerRepository;

    @PostMapping
    public ResponseEntity<Customer>
    createCustomer(@RequestBody Customer customer)
    {
        // Hash the password before saving
        //PasswordCallback customer;
        Punycode passwordEncoder = null;
        customer.setPassword(String.valueOf(passwordEncoder.encode(customer.getPassword())));

        Customer savedCustomer = customerRepository.save(customer);
        return ResponseEntity.created(URI.create("/api/customers/"
                + savedCustomer.getId()))
                .body(savedCustomer);

    }

    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(@RequestParam String name,
                                                     @RequestParam String email,
                                                     @RequestParam String password) {
        // Hash the password before saving
        Punycode passwordEncoder = null;
        password = String.valueOf(passwordEncoder.encode(password));

        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);

        Customer savedCustomer = customerRepository.save(customer);
        return ResponseEntity.created(URI.create("/api/customers/" + savedCustomer.getId()))
                .body(savedCustomer);

    }
}
