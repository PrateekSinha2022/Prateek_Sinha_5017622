package com.example.Week4_Question4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4Question4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
