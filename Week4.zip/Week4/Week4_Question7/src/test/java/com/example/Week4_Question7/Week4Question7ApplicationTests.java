package com.example.Week4_Question7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4Question7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
