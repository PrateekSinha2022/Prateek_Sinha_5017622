package com.example.Week4_Question7;

public @interface Mapper {
}
