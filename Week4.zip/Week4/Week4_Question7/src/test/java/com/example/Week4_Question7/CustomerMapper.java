package com.example.Week4_Question7;

@Mapper
public interface CustomerMapper {
    <Customer> CustomerDTO customerToCustomerDTO(Customer customer);
    <Customer> Customer customerDTOToCustomer(CustomerDTO customerDTO);
}
