package com.example.Week4_Question7;

public class BookDTO {
    private Long id;
    private String title;
    private String author;
    private String isbn;
    private Double price;

    // Getters and setters
}
