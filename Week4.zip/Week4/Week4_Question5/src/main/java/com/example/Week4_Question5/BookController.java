package com.example.Week4_Question5;

import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.print.Book;

@RestController
@RequestMapping("/api/books")
public class BookController {

    // ... other methods ...

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBook(@PathVariable Long id) {
        SimpleJpaRepository bookRepository = null;
        Book book = (Book) bookRepository.findById(id).orElse(null);

        if (book == null) {
            return ResponseEntity.notFound().build();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Book-Author", book.getPageFormat().toString());
        headers.add("X-Book-Published", book.getPrintable().toString());

        return ResponseEntity.ok().headers(headers).body(book);
    }
}
