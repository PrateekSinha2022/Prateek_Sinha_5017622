package com.example.Week4_Question8;

@Mapper
public interface CustomerMapper {
    <Customer> CustomerDTO customerToCustomerDTO(Customer customer);
    <Customer> Customer customerDTOToCustomer(CustomerDTO customerDTO);
}
