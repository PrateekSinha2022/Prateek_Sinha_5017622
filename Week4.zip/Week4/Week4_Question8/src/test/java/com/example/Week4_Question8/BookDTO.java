package com.example.Week4_Question8;

import org.antlr.v4.runtime.misc.NotNull;

public class BookDTO {
    @NotNull
    @Size(min = 3, max = 100)
    private String title;

    @NotNull
    @Size(min = 3, max = 100)
    private String author;

    @NotNull
    @Size(min = 10, max = 13)
    private String isbn;

    @NotNull
    @Min(0)
    private Double price;

    // ... other fields and getters/setters
}