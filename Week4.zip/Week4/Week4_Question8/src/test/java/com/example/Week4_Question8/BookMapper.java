package com.example.Week4_Question8;

import java.awt.print.Book;

@Mapper
public interface BookMapper {
    BookDTO bookToBookDTO(Book book);
    Book bookDTOToBook(BookDTO bookDTO);
}
