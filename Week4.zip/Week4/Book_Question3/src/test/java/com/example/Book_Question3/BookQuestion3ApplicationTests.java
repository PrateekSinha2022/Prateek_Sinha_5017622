package com.example.Book_Question3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookQuestion3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
