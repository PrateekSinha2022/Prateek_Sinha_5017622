package com.example.Book_Question3;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping("/books")
public class BookController<List>
        {

@GetMapping("/{id}")
public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        // Replace with actual logic to fetch book by id
        Book book = new Book(); // ...
        return new ResponseEntity<>(book, HttpStatus.OK);
        }

@GetMapping
public ResponseEntity<List<Book>> getBooksByQuery(@RequestParam(required = false) String title,
@RequestParam(required = false) String author) {
        // Replace with actual logic to filter books by title and author
        List books = new List(); // ...
        return new ResponseEntity<>(books, HttpStatus.OK);
        }
        }