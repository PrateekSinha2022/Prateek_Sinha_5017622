package com.example.Week3_Question5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week3Question5Application {

	public static void main(String[] args) {
		SpringApplication.run(Week3Question5Application.class, args);
	}

}
