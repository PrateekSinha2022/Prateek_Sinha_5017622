package com.example.EmployeeManagementSystem_Question1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemQuestion1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemQuestion1Application.class, args);
	}

}
