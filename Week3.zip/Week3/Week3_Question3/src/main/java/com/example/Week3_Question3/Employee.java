package com.example.Week3_Question3;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jdk.jfr.Enabled;

@Entity
public class Employee {
    @Id
    private int id;
    private String name;
    private String email;

    @Column(name = "department")
    private String department;
}
