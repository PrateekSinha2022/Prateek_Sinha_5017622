package com.example.Week3_Question3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3Question3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
