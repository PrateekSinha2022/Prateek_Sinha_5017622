package com.example.Week3_Question7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3Question7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
