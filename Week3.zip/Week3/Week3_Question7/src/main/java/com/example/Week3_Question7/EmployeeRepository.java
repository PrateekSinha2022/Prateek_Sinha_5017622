package com.example.Week3_Question7;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

    @Query("select* from Employee e where e.name=?1")
    List<Employee> findByEmployeeName(String name);

    @Query(name="Employee.findAllOrderedByName")
    List<Employee> nameordered();


}
