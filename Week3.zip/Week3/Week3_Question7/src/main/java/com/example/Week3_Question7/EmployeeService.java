package com.example.Week3_Question7;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository repo;

    public List<Employee> read()
    {
        return repo.findAll();
    }

    public void create(Employee emp)
    {
        repo.save(emp);
    }

    public void update(Employee emp)
    {
        repo.save(emp);
    }

    public void delete(int i)
    {
        repo.deleteById(i);
    }

    public List<Employee> getEmployeeOrdered()
    {
        return repo.nameordered();

    }

    public Page<Employee> getEmployees(int page,int size,String sortby,String direction)
    {
        Sort.Direction sortDIrection=Sort.Direction.fromString(direction.toUpperCase());
        Pageable pageable= PageRequest.of(page,size,Sort.by(sortDIrection,sortby));
        return repo.findAll(pageable);
    }

}

