package com.example.EmployeeManagementSystem;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;

@Entity
public class Employee {
    @Id
    private int id;
    private String name;
    private String email;

    @Column(name = "department")
    private String department;

    
}
