package com.example.Week3_Question9;

public class EmployeeDTO
{
    private int id;
    private String name;
    private String department;

    public EmployeeDTO(int id,String name,String department)
    {
        this.id=id;
        this.name=name;
        this.department=department;
    }
}
