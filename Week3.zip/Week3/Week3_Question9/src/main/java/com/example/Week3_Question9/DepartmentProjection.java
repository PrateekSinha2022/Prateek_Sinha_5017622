package com.example.Week3_Question9;
import org.springframework.beans.factory.annotation.Value;
public interface DepartmentProjection {

    int getId();
    String getDepartmentName();

    @Value("#{target.employee.size()}")
    Integer getEmployeeSize();
}
