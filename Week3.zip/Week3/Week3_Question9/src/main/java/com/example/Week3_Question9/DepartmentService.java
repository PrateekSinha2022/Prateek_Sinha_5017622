package com.example.Week3_Question9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    DepartmentRepository repo;

    public List<Department> read()
    {
        return repo.findAll();
    }

    public void create(Department dept)
    {
        repo.save(dept);
    }

    public void update(Department dept)
    {
        repo.save(dept);
    }

    public void delete(int i)
    {
        repo.deleteById(i);
    }
}
