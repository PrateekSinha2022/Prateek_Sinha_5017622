package com.example.Week3_Question9;

public class DepartmentDTO {

    private int id;
    private String department;

    private int employeeCount;

    public DepartmentDTO(int id,String department,int employeeCount)
    {
        this.id=id;
        this.department=department;
        this.employeeCount=employeeCount;
    }
}
