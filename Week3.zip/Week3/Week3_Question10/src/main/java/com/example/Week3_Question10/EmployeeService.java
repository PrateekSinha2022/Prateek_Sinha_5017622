package com.example.Week3_Question10;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Transactional
    public void saveEmployees(List<Employee> employees) {
        int batchSize = 50;
        for (int i = 0; i < employees.size(); i++) {
            employeeRepository.save(employees.get(i));
            if (i > 0 && i % batchSize == 0) {
                // Flush and clear the session
                employeeRepository.flush();
                employeeRepository.clear();
            }
        }
        // Flush remaining records
        employeeRepository.flush();
    }
}
