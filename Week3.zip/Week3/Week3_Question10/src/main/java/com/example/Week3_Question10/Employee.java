package com.example.Week3_Question10;

import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "email")
    private String email;

    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
    private Boolean debug = false; // Custom Hibernate type for boolean values
    @Column(name = "active")
    private Boolean active;

    // Custom ID generation strategy
    @Id
    @GeneratedValue(generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "uuid2")
    private String uuid;

    // Getters and Setters
}

