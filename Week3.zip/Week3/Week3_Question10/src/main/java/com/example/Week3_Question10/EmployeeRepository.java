package com.example.Week3_Question10;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    void clear();
    // Custom repository methods
}

