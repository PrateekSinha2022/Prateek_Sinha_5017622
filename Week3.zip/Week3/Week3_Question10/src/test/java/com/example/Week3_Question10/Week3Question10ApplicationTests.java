package com.example.Week3_Question10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3Question10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
