package com.example.Week3_Question8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3Question8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
