package com.example.Week3_Question8;
import org.springframework.beans.factory.annotation.Value;
public interface DepartmentProjection {

    int getId();
    String getDepartmentName();

    @Value("#{target.employee.size()}")
    Integer getEmployeeSize();
}
