package com.example.Week3_Question8;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department,Integer> {
    @Query("SELECT d.id AS id, d.departmentName AS departmentName, SIZE(d.employees) AS employeeCount FROM Department d")
    List<DepartmentProjection> findDepartmentProjections();

    @Query("SELECT new com.example.DepartmentDTO(d.id, d.departmentName, SIZE(d.employees)) FROM Department d")
    List<DepartmentDTO> findDepartmentDTOs();
}
