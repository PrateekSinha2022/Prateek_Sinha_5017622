package com.example.Week3_Question8;
import org.springframework.beans.factory.annotation.Value;

public interface EmployeeProjection {

    int getId();
    String getName();

    @Value("#{target.department.department}")
    String getDepartmentName();
}
