package com.example.Week3_Question4;

import jakarta.persistence.*;

import java.util.List;
@Entity
public class Department {
    @Id
    private int id;
    private String name;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="fk_department",referencedColumnName = "department")
    private List<Employee> employee;  //Since one department can have more than 1 employees, so a list is needed

}
