package com.example.Week3_Question4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @GetMapping("/employee")
    public List<Employee> emp()
    {
        return employeeService.read();
    }

    @PostMapping("/employee")
    public void addEmployee(@RequestBody Employee emp)
    {
        employeeService.create(emp);
    }

    @PutMapping("/employee")
    public void updateEmployee(@RequestBody Employee emp)
    {
        employeeService.update(emp);
    }

    @DeleteMapping("/employee/{id}")
    public void deleteEmployee(@PathVariable int id)
    {
        employeeService.delete(id);
    }
}
