package com.example.Week3_Question4;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {
    @Id
    private int id;
    private String name;
    private String email;

    @Column(name = "department")
    private String department;
}
