package com.example.Week3_Question4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository repo;

    public List<Employee> read()
    {
        return repo.findAll();
    }

    public void create(Employee emp)
    {
        repo.save(emp);
    }

    public void update(Employee emp)
    {
        repo.save(emp);
    }

    public void delete(int i)
    {
        repo.deleteById(i);
    }
}
