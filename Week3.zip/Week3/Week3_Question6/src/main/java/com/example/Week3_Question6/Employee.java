package com.example.Week3_Question6;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;

@NamedQuery(name="Employee.findAllOrderedByName", query="select * from employee e order by e.name asc")
@Entity
public class Employee {
    @Id
    private int id;
    private String name;
    private String email;

    @Column(name = "department")
    private String department;
}
