package com.example.Week3_Question6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.MergedAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.awt.print.Pageable;
import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @GetMapping("/employee")
    /*public List<Employee> emp()
    {
        return employeeService.read();
    }*/

    public Page<Employee> getEmployees(
            @RequestParam(value = "page",defaultValue = "0") int page,
            @RequestParam(value = "size",defaultValue = "10") int size,
            @RequestParam(value = "sortby",defaultValue = "name") String sortby,
            @RequestParam(value = "direction",defaultValue = "asc") String direction
    )
    {
        return employeeService.getEmployees(page, size, sortby, direction);
    }

    @PostMapping("/employee")
    public void addEmployee(@RequestBody Employee emp)
    {
        employeeService.create(emp);
    }

    @PutMapping("/employee")
    public void updateEmployee(@RequestBody Employee emp)
    {
        employeeService.update(emp);
    }

    @DeleteMapping("/employee/{id}")
    public void deleteEmployee(@PathVariable int id)
    {
        employeeService.delete(id);
    }
}
