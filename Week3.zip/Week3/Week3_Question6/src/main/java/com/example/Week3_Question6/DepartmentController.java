package com.example.Week3_Question6;

import jakarta.persistence.Entity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Entity
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;

    @GetMapping("/department")
    public List<Department> dep()
    {
        return departmentService.read();
    }

    @PostMapping("/department")
    public void create(@RequestBody Department dept)
    {
        departmentService.create(dept);
    }

    @PutMapping("/department")
    public void update(@RequestBody Department dept)
    {
        departmentService.update(dept);
    }

    @DeleteMapping("/department/{i}")
    public void delete(@PathVariable int i)
    {
        departmentService.delete(i);
    }
}
