public class TaskManagement {
    Node head;

    public void add(Task task)
    {
        Node newNode = new Node(task);
        if(head==null)
            head=newNode;
        else {
            Node temp=head;
            while(temp.next!=null)
            {
                temp=temp.next;
            }
            temp.next=newNode;
        }
    }

    public Task search(int id)
    {
        Node temp=head;
        while(temp.next!=null)
        {
            if(temp.data.taskid==id)
                return temp.data;
        }
        return null;
    }

    public void traverse()
    {
        Node temp=head;
        while(temp.next!=null){
            System.out.println(temp.data.taskid+" is "+temp.data.taskName);
        }
    }

    public void delete(int id)
    {
        if (head==null)
            return;
        if(head.data.taskid==id)
        {
            head=head.next;
            return;
        }
        Node temp=head;
        while(temp.next!=null)
        {
            if(temp.data.taskid==id)
            {
                temp.next=temp.next.next;
                return;
            }
            temp=temp.next;
        }
    }
}
