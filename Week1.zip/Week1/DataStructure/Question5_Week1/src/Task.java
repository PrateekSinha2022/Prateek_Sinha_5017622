public class Task {
    int taskid;
    String taskName;
    String status;

    public Task(int id,String name,String status)
    {
        this.taskid=id;
        this.taskName=name;
        this.status=status;
    }
}
