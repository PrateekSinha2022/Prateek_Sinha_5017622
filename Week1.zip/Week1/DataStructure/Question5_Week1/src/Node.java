public class Node {
    Task data;
    Node next;

    public Node(Task data)
    {
        this.data=data;
        this.next = null;
    }
}
