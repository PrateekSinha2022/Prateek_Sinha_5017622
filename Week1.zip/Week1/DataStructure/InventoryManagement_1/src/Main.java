public class Main{
    public static void main(String []args)
    {
        Product product=new Product(1,"Soap",50,20.5);
        Inventory invent=new Inventory();
        invent.addProduct(product);

        invent.view(product);
    }
}