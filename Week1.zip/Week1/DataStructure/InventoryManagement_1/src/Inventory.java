import java.util.HashMap;

public class Inventory {
    HashMap<Integer,Product> inventory=new HashMap<>();

    public void addProduct(Product product)
    {
        inventory.put(product.productid,product);
    }
    public void updateProduct(Product product)
    {
        inventory.put(product.productid,product);
    }
    public void deleteProduct(Product product)
    {
        inventory.remove(product.productid);
    }

    public void view(Product product)
    {
        System.out.println(product.productname+" with "+product.productid+" is available at "+product.price);
    }
}
