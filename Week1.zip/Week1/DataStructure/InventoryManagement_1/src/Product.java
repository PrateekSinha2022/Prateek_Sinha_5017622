import java.util.HashMap;

public class Product {
    int productid;
    String productname;
    int quantiy;
    double price;

    public Product(int productid,String productname,int quantiy,double price)
    {
        this.productid=productid;
        this.productname=productname;
        this.quantiy=quantiy;
        this.price=price;
    }
}
