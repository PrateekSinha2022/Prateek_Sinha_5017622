public class Search {
    Book[] books;
    int size=0;

    public Search(int size)
    {
        books = new Book[size];
        this.size=size;
    }

    public int linear(String title)
    {
        for(int i=0;i<size;i++)
        {
            if(books[i].title.equals(title))
            {
                return 1;
            }
        }
        return 0;
    }

    public int binary(String title)
    {
        int low=0;
        int high = size-1;

        while(low<=high)
        {
            int m = low+(high-low)/2;
            int comp=books[m].title.compareToIgnoreCase(title);
            if(comp==0)
            {
                return 1;
            } else if (comp>0) {
                high=m-1;
            }
            else
            {
                low=m+1;
            }
        }
        return 0;
    }
}
