public class Book {
    int bookId;
    String title;
    String author;
     public Book(int id,String title,String author)
     {
         this.bookId=id;
         this.author=author;
         this.title=title;
     }
}
