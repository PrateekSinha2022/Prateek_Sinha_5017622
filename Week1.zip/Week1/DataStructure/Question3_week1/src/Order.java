public class Order {
    int orderId;
    String customerName;
    String totalPrice;
}
