public class Search {
    public static int linear(Product[] products,int id)
    {
        int i;
        for(i=0;i<products.length;i++)
        {
            if(products[i].productid==id)
            {
                return i
            }
        }
        return -1;
    }

    public static int binary(Product[] products,int id)
    {
        int l=0;
        int r= products.length-1;

        while(l<=r)
        {
            int m=l+(r-l)/2;
            int key=products[m].productid;
            if(products[m].productid<key)
                l=m+1;
            else if (products[m].productid==key) {
                return m;
            }
            else {
                r=m-1;
            }
        }
        return -1;
    }
}
