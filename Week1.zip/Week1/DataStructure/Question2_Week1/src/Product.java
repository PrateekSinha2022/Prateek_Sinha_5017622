public class Product {
    int productid;
    String productname;
    String category;
}
