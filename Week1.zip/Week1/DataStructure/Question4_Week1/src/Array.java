import java.util.*;
public class Array {
   Employee[] employees;
   int size;
   public Array(int capacity)
   {
      employees =new Employee[capacity];
      size=0;
   }

   public void addEmployee(Employee employee)
   {
      if(size< employees.length)
      {
         employees[size]=employee;
         size++;
      }
      else {
         System.out.println("Array full");
      }
   }
   public void EmploeeSearch(int id)
   {
      for(int i=0;i<size;i++)
      {
         if(employees[i].employeeId==id)
         {
            System.out.println("Available");
         }
      }
   }

   public void display()
   {
      for(int i=0;i<size;i++)
      {
         System.out.println(employees[i].employeeId+" with "+employees[i].name);
      }
   }


   public void delete(int id)
   {
      int index=-1;
      for(int i=0;i<size;i++)
      {
         if(employees[i].employeeId==id)
         {
            index = i;
         }
      }
      if(index!=-1)
      {
         System.arraycopy(employees,index+1,employees,index,size-index-1);
         size--;
      }
      else {
         System.out.append("Employee not found");
      }
   }


}
