public class Finance {
    public double futureValue(double presentValue,double interest,int period)
    {
        if(period==0)
            return presentValue;
        else
        {
            double futureValueNextPeriod= presentValue*(1+interest);
            return futureValue(futureValueNextPeriod,interest,period-1);
        }
    }
}
