public class CustomerService {
    private CustomerRepository cust;

    public CustomerService(CustomerRepository cust)
    {
        this.cust=cust;
    }
    public String customerName(int id)
    {
        return cust.findCustomerId(id);
    }
}
