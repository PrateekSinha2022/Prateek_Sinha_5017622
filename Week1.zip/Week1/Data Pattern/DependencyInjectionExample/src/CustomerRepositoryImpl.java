public class CustomerRepositoryImpl implements CustomerRepository{
    public String findCustomerId(int id)
    {
        return "Sam"; //Returning a hardcoded customer name
    }
}
