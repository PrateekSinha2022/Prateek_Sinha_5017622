public class InjectTest {
    public static void main(String []args)
    {
        CustomerRepository ct=new CustomerRepositoryImpl();
        CustomerService cust=new CustomerService(ct);

        String name=ct.findCustomerId(5);
        System.out.println("The name is "+name);
    }
}
