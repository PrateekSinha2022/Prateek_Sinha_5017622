public interface CustomerRepository {
    String findCustomerId(int id);
}
