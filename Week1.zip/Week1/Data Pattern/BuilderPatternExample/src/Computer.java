public class Computer {
    private final int cpu;
    private final int ram;
    private final int storage;

    private Computer(UserBuilder builder)
    {
        this.cpu=builder.cpu;
        this.ram=builder.ram;
        this.storage=builder.storage;
    }
    public int getCpu()
    {
        return cpu;
    }
    public int getRam(){
        return ram;
    }
    public int getStorage(){
        return storage;
    }
    public static class UserBuilder {
        int cpu;
        int ram;
        int storage;
        public UserBuilder setram(int ram)
        {
            this.ram=ram;
            return this;
        }
        public UserBuilder setcpu(int cpu)
        {
            this.cpu=cpu;
            return this;
        }
        public UserBuilder setstorage(int storage)
        {
            this.storage=storage;
            return this;
        }
        public Computer build()
        {
            return new Computer(this);
        }

    }

}
