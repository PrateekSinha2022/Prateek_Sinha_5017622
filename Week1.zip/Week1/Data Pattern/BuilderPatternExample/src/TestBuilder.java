public class TestBuilder {
    public static void main(String []args)
    {
        Computer ob=new Computer.UserBuilder()
                .setcpu(80)
                .setram(8)
                .setstorage(512)
                .build();
        System.out.println(ob.getCpu());
        System.out.println(ob.getRam());
        System.out.println(ob.getStorage());
    }
}
