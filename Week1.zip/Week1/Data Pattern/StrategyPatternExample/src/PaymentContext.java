public class PaymentContext{
    PaymentStrategy payment;

    public PaymentContext(PaymentStrategy pay)
    {
        this.payment=pay;
    }

    public void paymentExecution(double amount)
    {
        payment.pay(amount);
    }
}
