public class PayPalPayment implements PaymentStrategy{

    private String mobile_no;

    public PayPalPayment(String mobile_no)
    {
        this.mobile_no=mobile_no;
    }

    public void pay(double amount)
    {
        System.out.println("Payment of "+amount+" successfully paid via Paypal");
    }
}
