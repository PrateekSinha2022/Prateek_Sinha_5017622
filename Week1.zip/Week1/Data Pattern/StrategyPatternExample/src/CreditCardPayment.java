public class CreditCardPayment implements PaymentStrategy{
    private String cardno;
    private String name;

    public CreditCardPayment(String no,String name)
    {
        this.cardno=no;
        this.name=name;
    }

    public void pay(double amount)
    {
        System.out.println("Payment of "+amount+" successfully paid via credit card");
    }


}
