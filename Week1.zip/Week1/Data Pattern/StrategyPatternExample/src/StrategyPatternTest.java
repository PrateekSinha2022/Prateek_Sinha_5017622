public class StrategyPatternTest {
    public static void main(String []args)
    {
        PaymentStrategy credpay=new CreditCardPayment("1234-56789-1234","Lokesh");
        PaymentContext pay1=new PaymentContext(credpay);
        
        pay1.paymentExecution(500);

        PaymentStrategy paypalpay=new PayPalPayment("9874561230");
        PaymentContext pay2=new PaymentContext(paypalpay);

        pay2.paymentExecution(700);
    }
}
