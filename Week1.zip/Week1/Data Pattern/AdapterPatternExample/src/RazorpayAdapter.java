public class RazorpayAdapter implements PaymentProcessor{
    private RazorpayGateway razorpay;
    public RazorpayAdapter(RazorpayGateway razorpay)
    {
        this.razorpay=razorpay;
    }

    public void processPayment(String paymentDetails)
    {
        String PaymentDetails=convertRazorpay(paymentDetails);
        RazorpayGateway.processRazorpayPayment(PaymentDetails);
    }

    private String convertRazorpay(String pay)
    {
        return "Payment Details: "+pay;
    }
}
