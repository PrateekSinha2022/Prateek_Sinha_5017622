public class AdapterPatternTest {
    public static void main(String []args)
    {
        PaymentProcessor payu = new PayuAdapter(new PayuGateway());
        payu.processPayment("payment information");

        PaymentProcessor razorpay=new RazorpayAdapter(new RazorpayGateway());
        razorpay.processPayment("payment razorpay");
    }
}
