public class PayuGateway {
    public static void processPayuPayment(String pay)
    {
        System.out.println("Process Payu Payment "+pay);
    }
}
