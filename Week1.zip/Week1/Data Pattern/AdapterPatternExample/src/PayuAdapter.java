public class PayuAdapter implements PaymentProcessor{
    private PayuGateway payu;

    public PayuAdapter(PayuGateway payu)
    {
        this.payu=payu;
    }

    public void processPayment(String paymentDetails)
    {
        String pay=convertPayu(paymentDetails);
        PayuGateway.processPayuPayment(pay);
    }

    private String convertPayu(String pay)
    {
        return "Payment details: "+pay;
    }
}
