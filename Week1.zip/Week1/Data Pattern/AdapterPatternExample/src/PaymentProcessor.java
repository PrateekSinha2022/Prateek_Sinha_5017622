public interface PaymentProcessor {
    void processPayment(String paymentDetails);
}
