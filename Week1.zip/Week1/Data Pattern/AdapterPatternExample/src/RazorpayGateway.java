public class RazorpayGateway {
    public static void processRazorpayPayment(String pay)
    {
        System.out.println("Process Razorpay Payment "+pay);
    }
}
