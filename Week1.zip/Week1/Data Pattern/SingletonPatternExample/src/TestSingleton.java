public class TestSingleton {
    public static void main(String []args)
    {
        Logger log1 = Logger.getInstance();
        Logger log2 = Logger.getInstance();

        if(log1==log2)
        {
            System.out.println("SingleTon successful");
        }
        else{
            System.out.println("SingleTon Unsuccessful");
        }
    }
}
