public class TestDecoratorClass {
    public static void main(String []args)
    {
        Notifier Emailnotifier = new EmailNotifier();
        Notifier sms = new SMSNotifierDecorator(Emailnotifier);
        Notifier slack = new SlackNotifierDecorator(sms);

        slack.send("Payment Successful");


    }
}
