public class StudentController {
    private Student student;
    private StudentView studentView;
    public StudentController(Student student,StudentView studentView)
    {
        this.student=student;
        this.studentView=studentView;
    }

    public void view()
    {
        studentView.displayStudentDetails(student.getName(), student.getId(), student.getGrade());
    }

    public void setStudentName(String name)
    {
        student.setName(name);
    }
    public void setStudentId(int id)
    {
        student.setId(id);
    }
    public void setStudentGrade(char grade)
    {
        student.setGrade(grade);
    }

}
