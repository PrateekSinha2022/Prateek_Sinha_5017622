public class MVCTest {
    public static void main(String []args)
    {
        Student student=new Student("Ravi",21,'A');
        StudentView view=new StudentView();

        StudentController st=new StudentController(student,view);

        st.view();

        st.setStudentGrade('B');
        st.setStudentId(54);
        st.setStudentName("Kapoor");

        st.view();
    }
}
