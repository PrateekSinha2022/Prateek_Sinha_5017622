public class Student {
    String name;
    int id;
    char grade;
    public Student(String name,int id,char grade)
    {
        this.name=name;
        this.id=id;
        this.grade=grade;
    }

    public String getName()
    {
        return this.name;
    }
    public int getId()
    {
        return this.id;
    }
    public char getGrade()
    {
        return this.grade;
    }

    public void setName(String name)
    {
        this.name=name;
    }
    public void setId(int id)
    {
        this.id=id;
    }
    public void setGrade(char grade)
    {
        this.grade=grade;
    }
}
