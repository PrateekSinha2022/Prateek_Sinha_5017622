public class StudentView {
    public void displayStudentDetails(String name,int id,char grade)
    {
        System.out.println("Name: "+name);
        System.out.println("Id: "+id);
        System.out.println("Grade: "+grade);
    }
}
