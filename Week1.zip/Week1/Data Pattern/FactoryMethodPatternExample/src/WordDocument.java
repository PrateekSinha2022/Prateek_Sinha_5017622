public class WordDocument implements Document{
    public void open()
    {
        System.out.println("Openeing Word Dcoument");
    }
    public void save()
    {
        System.out.println("Saving word document");
    }
    public void close()
    {
        System.out.println("Closing word Document");
    }
}
