public class PdfDocument implements Document {
    public void open()
    {
        System.out.println("Openeing Pdf Dcoument");
    }
    public void save()
    {
        System.out.println("Saving Pdf document");
    }
    public void close()
    {
        System.out.println("Closing Pdf Document");
    }
}
