public class ExcelDocument implements Document{
    public void open()
    {
        System.out.println("Openeing excel Dcoument");
    }
    public void save()
    {
        System.out.println("Saving excel document");
    }
    public void close()
    {
        System.out.println("Closing excel Document");
    }
}
