public class TestFactoryMethod {
    public static void main(String []args)
    {
        DocumentFactory wordDoc = new WordDocumentFactory();
        Document word = wordDoc.createDocument();
        word.open();
        word.save();
        word.close();

        DocumentFactory pdfDoc = new PdfDocumentFactory();
        Document pdf = pdfDoc.createDocument();
        pdf.open();
        pdf.save();
        pdf.close();

        DocumentFactory excelDoc = new ExcelDocumentFactory();
        Document excel = excelDoc.createDocument();
        excel.open();
        excel.save();
        excel.close();
    }
}
