public class CommandPatternTest {
    public static void main(String []args)
    {
        Light light=new Light();

        Command on=new LightOnCommand(light);
        RemoteControl rc1=new RemoteControl(on);
        rc1.executeCommand();

        Command off=new LightOffCommand(light);
        RemoteControl rc2=new RemoteControl(off);
        rc2.executeCommand();
    }
}
