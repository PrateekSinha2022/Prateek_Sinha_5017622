public class RemoteControl {
    private Command com;
    public RemoteControl(Command com)
    {
        this.com=com;
    }

    public void executeCommand()
    {
        com.execute();
    }
}
