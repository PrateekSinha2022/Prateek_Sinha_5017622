public class WebApp implements Observer{
    public void update(double price)
    {
        System.out.println("WebApp: Price changed to "+price);
    }
}
