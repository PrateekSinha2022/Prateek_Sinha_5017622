public class ObserverPatternTest {
    public static void main(String []args)
    {
        StockMarket sm=new StockMarket();

        Observer mobile=new MobileApp();
        Observer web=new WebApp();

        sm.register(mobile);
        sm.register(web);

        sm.setPrice(100);
        sm.setPrice(200);

        sm.deregister(web);

        sm.setPrice(300);
    }
}
