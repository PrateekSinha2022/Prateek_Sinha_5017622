import java.util.ArrayList;
import java.util.List;

public class StockMarket implements Stock{
    private static List<Observer> obs = new ArrayList<>();
    private double price;

    public void setPrice(double price)
    {
        this.price=price;
        notifyObserver();
    }

    public void register(Observer observer)
    {
        obs.add(observer);
    }

    public void deregister(Observer observer)
    {
        obs.remove(observer);
    }
    public void notifyObserver()
    {
        for(Observer observer:obs)
            observer.update(price);
    }
}
