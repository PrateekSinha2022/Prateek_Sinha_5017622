import java.awt.*;

public class RealImage implements Image{
    private String servername;
    public RealImage(String servername)
    {
        this.servername=servername;
        loadFromServer(servername);
    }

    private void loadFromServer(String servername)
    {
        System.out.println("Loading "+servername);

        try
        {
            Thread.sleep(5000);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void display()
    {
        System.out.println("Displaying "+servername);
    }
}
