public class ProxyPatterTest {
    public static void main(String []args)
    {
        Image img = new ProxyImage("img.jpg");

        img.display(); //Displaying image after loading. The loading time is 5s
        img.display(); //Displaying the already loaded image
    }
}
