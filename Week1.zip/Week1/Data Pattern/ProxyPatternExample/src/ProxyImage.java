public class ProxyImage implements Image{
    private RealImage realimage;
    private String servername;

    public ProxyImage(String servername)
    {
        this.servername=servername;
    }

    public void display()
    {
        if(realimage==null)
        {
            realimage = new RealImage(servername);
        }
        realimage.display();
    }
}
