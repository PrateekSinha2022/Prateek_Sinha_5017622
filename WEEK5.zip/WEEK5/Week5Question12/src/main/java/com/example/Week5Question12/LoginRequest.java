package com.example.Week5Question12;

public class LoginRequest {
    private String username;
    private String password;

    // Getters and setters
}

