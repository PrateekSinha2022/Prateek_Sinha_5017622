package com.example.Week5Question14;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;

@SpringBootTest
public class BookRepositoryIntegrationTest {

    @Autowired
    private BookRepository bookRepository;

    @Test
    @Sql(scripts = "/test-schema.sql") // Optional: Define schema
    @Sql(scripts = "/test-data.sql")   // Optional: Define test data
    public void testFindBooks() {
        // Test logic here
    }
}

