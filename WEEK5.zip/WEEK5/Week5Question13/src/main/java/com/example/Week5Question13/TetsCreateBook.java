package com.example.Week5Question13;


import java.awt.print.Book;

public class TetsCreateBook {
    @Test
    public void testCreateBook() throws Exception {
        Book book = new Book(1L, "New Book", "New Author");

        Object bookService;
        when(bookService.createBook(any(Book.class))).thenReturn(book);

        mockMvc.perform(post("/api/books")
                        .contentType("application/json")
                        .content("{\"title\":\"New Book\", \"author\":\"New Author\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("New Book"))
                .andExpect(jsonPath("$.author").value("New Author"));
    }
}