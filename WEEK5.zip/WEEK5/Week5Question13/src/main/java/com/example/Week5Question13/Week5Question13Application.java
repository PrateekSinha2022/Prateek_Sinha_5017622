package com.example.Week5Question13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5Question13Application {

	public static void main(String[] args) {
		SpringApplication.run(Week5Question13Application.class, args);
	}

}
