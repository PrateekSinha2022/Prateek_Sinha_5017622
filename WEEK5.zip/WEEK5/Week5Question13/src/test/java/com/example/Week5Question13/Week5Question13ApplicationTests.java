package com.example.Week5Question13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5Question13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
