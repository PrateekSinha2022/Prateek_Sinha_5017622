package com.example.Week5Question11;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Counter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final Counter bookRequestCounter;

    @Autowired
    public BookService(MeterRegistry meterRegistry) {
        this.bookRequestCounter = meterRegistry.counter("book_requests_total", "type", "service");
    }

    public void getBook(Long id) {
        bookRequestCounter.increment();
        // Your logic to get a book
    }
}
