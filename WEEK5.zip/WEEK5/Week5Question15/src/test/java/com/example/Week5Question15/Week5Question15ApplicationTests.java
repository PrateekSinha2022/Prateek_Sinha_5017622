package com.example.Week5Question15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5Question15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
