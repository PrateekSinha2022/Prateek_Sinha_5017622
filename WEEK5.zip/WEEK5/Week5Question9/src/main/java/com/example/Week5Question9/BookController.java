package com.example.Week5Question9;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;
    private final BookResourceAssembler assembler;

    public BookController(BookService bookService, BookResourceAssembler assembler) {
        this.bookService = bookService;
        this.assembler = assembler;
    }

    @GetMapping("/{id}")
    public EntityModel<BookResource> getBookById(@PathVariable Long id) {
        Book book = bookService.findById(id);
        return EntityModel.of(assembler.toModel(book));
    }

    @GetMapping
    public CollectionModel<BookResource> getAllBooks() {
        List<BookResource> books = bookService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(books);
    }
}

