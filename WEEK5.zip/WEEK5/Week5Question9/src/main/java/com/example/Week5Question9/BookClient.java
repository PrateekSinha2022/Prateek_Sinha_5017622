package com.example.Week5Question9;

import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

public class BookClient {

    private final WebClient webClient;

    public BookClient(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
    }

    public void getBook(Long id) {
        try {
            String response = this.webClient
                    .get()
                    .uri("/books/{id}", id)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println(response);
        } catch (WebClientResponseException e) {
            e.printStackTrace();
        }
    }
}

