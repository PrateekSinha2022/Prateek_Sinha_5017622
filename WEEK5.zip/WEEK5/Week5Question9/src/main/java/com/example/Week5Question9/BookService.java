package com.example.Week5Question9;

import java.util.Arrays;

public class BookService {
    public Book findById(Long id) {
    }

    public Arrays findAll() {
    }
}
