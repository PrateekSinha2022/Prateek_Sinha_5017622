package com.example.Week5Question9;

import org.springframework.hateoas.RepresentationModel;

import java.awt.print.Book;

public class BookResource extends RepresentationModel<BookResource> {

    private final Book book;

    public BookResource(Book book) {
        this.book = book;
    }

    public Book getBook() {
        return book;
    }
    public Book add()
}
