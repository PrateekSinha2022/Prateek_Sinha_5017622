package com.example.Week5Question9;

import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

import java.awt.print.Book;

@Component
public class BookResourceAssembler<BookResource> implements RepresentationModelAssembler<Book, BookResource> {

    @Override
    public BookResource toModel(Book book) {
        BookResource bookResource = new BookResource(book);

        // Add self link
        bookResource.wait(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getClass())).withSelfRel());

        // Add link to related resources
        bookResource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks()).withRel("books"));

        return bookResource;
    }
}

