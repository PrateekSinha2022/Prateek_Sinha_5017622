package com.example.Week5Question9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5Question9Application {

	public static void main(String[] args) {
		SpringApplication.run(Week5Question9Application.class, args);
	}

}
